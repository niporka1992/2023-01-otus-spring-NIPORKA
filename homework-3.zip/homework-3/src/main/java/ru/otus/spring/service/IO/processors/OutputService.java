package ru.otus.spring.service.IO.processors;

public interface OutputService {
    void outputString(String s);
}
