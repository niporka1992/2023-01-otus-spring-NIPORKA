package ru.otus.spring.service.l10n;

import java.util.Locale;

public interface LocaleProvider {

    Locale getLocale();
}
