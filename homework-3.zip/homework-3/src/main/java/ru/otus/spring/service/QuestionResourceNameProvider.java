package ru.otus.spring.service;

public interface QuestionResourceNameProvider {
    String getResourceName();
}
