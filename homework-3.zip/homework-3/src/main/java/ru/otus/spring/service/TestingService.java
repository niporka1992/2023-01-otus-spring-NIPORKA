package ru.otus.spring.service;

import ru.otus.spring.domain.Student;
import ru.otus.spring.domain.TestingResult;

public interface TestingService {
     void executeExam();

    private TestingResult executeExamFor(Student student) {
        return null;
    }
}
