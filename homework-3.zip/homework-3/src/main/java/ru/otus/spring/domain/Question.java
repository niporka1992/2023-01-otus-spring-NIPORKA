package ru.otus.spring.domain;

import lombok.Data;

@Data
public class Question {
    private final String name;
    private final String answer;

}
