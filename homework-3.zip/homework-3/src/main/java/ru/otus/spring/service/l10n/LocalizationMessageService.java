package ru.otus.spring.service.l10n;

public interface LocalizationMessageService {

    String localizeTheMessage(String message);
}
