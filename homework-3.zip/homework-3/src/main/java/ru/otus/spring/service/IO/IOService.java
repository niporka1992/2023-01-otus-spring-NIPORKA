package ru.otus.spring.service.IO;

import ru.otus.spring.service.IO.processors.InputService;
import ru.otus.spring.service.IO.processors.OutputService;

public interface IOService extends InputService, OutputService {

}
