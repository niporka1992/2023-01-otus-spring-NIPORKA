package ru.otus.spring.service.IO.processors;

public interface InputService {
    String readString();
}
