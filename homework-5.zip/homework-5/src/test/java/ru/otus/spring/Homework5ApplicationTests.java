package ru.otus.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homework5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
