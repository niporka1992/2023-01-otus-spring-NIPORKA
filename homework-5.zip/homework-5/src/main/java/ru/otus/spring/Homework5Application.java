package ru.otus.spring;

import lombok.SneakyThrows;
import org.h2.tools.Console;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import ru.otus.spring.dao.AuthorDao;
import ru.otus.spring.dao.BookDao;
import ru.otus.spring.dao.GenreDao;
import ru.otus.spring.domain.Author;
import ru.otus.spring.domain.Book;
import ru.otus.spring.domain.Genre;
import ru.otus.spring.service.AuthorService;

import java.sql.SQLException;

@SpringBootApplication
public class Homework5Application {

    @SneakyThrows
    public static void main(String[] args) throws SQLException {
        //   SpringApplication.run(Homework5Application.class, args);
        //        SpringApplication.run(Homework5Application.class, args);
        //  Console.main(args);


        ApplicationContext context = SpringApplication.run(Homework5Application.class, args);
          Console.main(args);
       /* BookDao bookDao = context.getBean(BookDao.class);
        AuthorDao authorDao = context.getBean(AuthorDao.class);
        GenreDao genreDao = context.getBean(GenreDao.class);

        //  AuthorDao authorDao = context.getBean(AuthorDao.class);
        AuthorService ss = context.getBean(AuthorService.class);

        Book expectedBook = new Book(4, "book", new Author(2, "Лев", "Толстой"),new Genre(1,"Фэнтези"));
        System.out.println(expectedBook);
        bookDao.insert(expectedBook);
        System.out.println(bookDao.getById(4));
*/
    }
}
