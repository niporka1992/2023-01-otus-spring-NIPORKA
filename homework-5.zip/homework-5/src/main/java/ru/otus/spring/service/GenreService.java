package ru.otus.spring.service;

import org.springframework.jdbc.support.KeyHolder;
import ru.otus.spring.domain.Genre;

import java.util.List;

public interface GenreService {
    long getCount();

    long save(Genre genre);

    List<Genre> findAll();

    Genre findById(long id);

    Genre findByName(String name);

    long updateById(long id, String name);

    long deleteById(long id);
}
