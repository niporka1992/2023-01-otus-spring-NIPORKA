package ru.otus.spring.dao;

import org.springframework.jdbc.support.KeyHolder;
import ru.otus.spring.domain.Book;

import java.security.Key;
import java.util.List;

public interface BookDao {
    long getCount();

    long insert(Book book);

    long updateById(long id, Book book);

    Book getById(long id);

    List<Book> getAll();

    long deleteById(long id);
}
