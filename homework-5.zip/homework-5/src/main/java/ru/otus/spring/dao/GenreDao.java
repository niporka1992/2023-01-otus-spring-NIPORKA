package ru.otus.spring.dao;

import org.springframework.jdbc.support.KeyHolder;
import ru.otus.spring.domain.Genre;

import java.util.List;

public interface GenreDao {
    long count();

    long insert(Genre genre);

    long updateById(long id, String name);

    Genre getById(long id);

    Genre getByName(String name);

    List<Genre> getAll();

    long deleteById(long id);
}
